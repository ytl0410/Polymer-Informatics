#!/usr/bin/env python3
"""Read-only workshop inventory; no ML imports, installs, or pickle loading."""

import argparse
import ast
import csv
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import sys

NOTEBOOKS = (
    '1_Overview.ipynb', '2_Supervised_Learning.ipynb',
    '3_Unsupervised_Learning.ipynb', '4_Generative_models.ipynb',
)
TABLES = {
    'Tg.csv': ('Smiles', 'Tg(C)'),
    'Eg.csv': ('Smiles', 'Eg(eV)'),
    'PolyInfo.csv': ('smiles',),
    'diCOOH.csv': ('Smiles',),
    '202207_smip_monset.csv': ('SMILES',),
}
REQUIRED = (*NOTEBOOKS, *TABLES, 'Tg.pth', 'workshop_config.py',
            'requirements-workshop.txt', 'tools/run_all_notebooks.py',
            'lstm_climber/network.py', 'lstm_climber/datamodules.py',
            'lstm_climber/utils.py', 'lstm_climber/__init__.py',
            'Columns_All.pickle', 'Corr_All.pickle', 'unique_list_All.pickle',
            'polymer.keys_All.pickle')


def source(cell):
    value = cell.get('source', '')
    return ''.join(value) if isinstance(value, list) else value


def inspect(project, check_environment=False):
    result = {'project': str(project), 'python': sys.version.split()[0],
              'interpreter': sys.executable, 'platform': platform.platform(),
              'errors': [], 'notes': [], 'tables': {}, 'notebooks': {},
              'saved_execution': {}, 'packages': {}}
    for name in REQUIRED:
        if not (project / name).is_file():
            result['errors'].append(f'Missing required file: {name}')
    for name, columns in TABLES.items():
        path = project / name
        if not path.is_file():
            continue
        with path.open(encoding='utf-8-sig', newline='') as handle:
            reader = csv.DictReader(handle)
            fields = reader.fieldnames or []
            missing = set(columns) - set(fields)
            count = sum(1 for _ in reader)
        result['tables'][name] = {'rows': count, 'columns': fields}
        if missing or not count:
            result['errors'].append(f'{name}: missing columns {sorted(missing)}; rows={count}')
    for name in NOTEBOOKS:
        path = project / name
        if not path.is_file():
            continue
        notebook = json.loads(path.read_text(encoding='utf-8'))
        cells = notebook.get('cells', [])
        for i, cell in enumerate(cells):
            if cell.get('cell_type') != 'code' or not source(cell).strip():
                continue
            text = source(cell)
            if any(line.lstrip().startswith(('!', '%')) for line in text.splitlines()):
                result['notes'].append(f'{name}, cell {i}: IPython syntax needs a live kernel check')
                continue
            try:
                ast.parse(text)
            except SyntaxError as exc:
                result['errors'].append(f'{name}, cell {i}: {exc.msg}')
        result['notebooks'][name] = {
            'nonempty_code_cells': sum(c.get('cell_type') == 'code' and bool(source(c).strip()) for c in cells),
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        }
        saved_path = project / 'dry_run_outputs' / name
        if saved_path.is_file():
            saved = json.loads(saved_path.read_text(encoding='utf-8')).get('cells', [])
            code = [c for c in saved if c.get('cell_type') == 'code' and source(c).strip()]
            errors = sum(o.get('output_type') == 'error' for c in code for o in c.get('outputs', []))
            unexecuted = sum(c.get('execution_count') is None for c in code)
            same = [(c.get('cell_type'), source(c)) for c in cells] == [(c.get('cell_type'), source(c)) for c in saved]
            result['saved_execution'][name] = {
                'errors': errors, 'unexecuted': unexecuted, 'source_matches': same,
                'evidence': 'historical saved output; not a new run',
            }
            if errors or unexecuted or not same:
                result['notes'].append(f'{name}: saved output is incomplete, failed, or differs from current source')
    requirements = project / 'requirements-workshop.txt'
    if check_environment and requirements.is_file():
        if sys.version_info[:2] != (3, 10):
            result['errors'].append('Pinned local baseline requires Python 3.10')
        for line in requirements.read_text().splitlines():
            if '==' not in line or line.lstrip().startswith('#'):
                continue
            package, expected = line.strip().split('==', 1)
            try:
                actual = importlib.metadata.version(package)
            except importlib.metadata.PackageNotFoundError:
                actual = None
            result['packages'][package] = {'expected': expected, 'installed': actual}
            if actual != expected:
                result['errors'].append(f'{package}: expected {expected}, found {actual}')
    result['notes'].append('Preflight does not validate chemistry, deserialize weights, or execute notebooks.')
    result['status'] = 'passed' if not result['errors'] else 'failed'
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', default=os.environ.get('POLYMER_WORKSHOP_ROOT', '.'))
    parser.add_argument('--check-environment', action='store_true', help='Compare this interpreter with the pinned requirements')
    args = parser.parse_args()
    try:
        result = inspect(Path(args.project).expanduser().resolve(), args.check_environment)
    except (OSError, ValueError, csv.Error) as exc:
        result = {'status': 'failed', 'errors': [f'{type(exc).__name__}: {exc}']}
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0 if result['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
