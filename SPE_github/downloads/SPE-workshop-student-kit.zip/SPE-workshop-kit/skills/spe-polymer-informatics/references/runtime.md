# Running and troubleshooting the actual workshop

## Local baseline

Use the repository's `requirements-workshop.txt` in an isolated Python 3.10
environment. The tested core versions are NumPy 1.26.4, pandas 2.1.4, RDKit
2023.9.6, scikit-learn 1.4.2, TensorFlow 2.15.1, torch 2.2.2, Lightning 2.2.5,
SHAP 0.45.1, SMiPoly 0.0.1, and setuptools 80.9.0. The requirements file is
authoritative for this version. The package excludes `.venv`; install locally.

From the project folder on macOS/Linux:

```bash
python3.10 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-workshop.txt
python -m pip check
python -m jupyter lab
```

On Windows, use `py -3.10 -m venv .venv` and
`.venv\Scripts\python.exe -m pip install -r requirements-workshop.txt`; invoke
Jupyter with that interpreter. Windows was not tested in the recorded run.

The kernel must use the same interpreter as installation. Inspect `sys.executable`
inside the kernel for import failures. The runner uses the `python3` kernelspec;
if it resolves to another environment, select/register a project-local kernel
and adapt `kernel_name` rather than reporting a false pass from another Python.

## Mode and execution

`workshop_config.py` defaults to dry-run mode. Set
`POLYMER_WORKSHOP_DRY_RUN=0` before kernel startup for full mode, then restart the
kernel if it was already imported. The runner explicitly chooses mode from its
`--full` flag; an environment variable alone does not change the runner's choice.

```bash
python tools/run_all_notebooks.py
python tools/run_all_notebooks.py --start-at 3
python tools/run_all_notebooks.py --full
```

The final command is a substantial training workload. Use it only when the user
requests full execution. Dry run includes full Tg feature construction, shortened
FNN/CV, 80 SHAP samples, and a small one-epoch LSTM trained on 512 structures.
Full mode currently uses five LSTM epochs; it is still not a convergence guarantee.

Historical successful durations were about 228/238/264/20 seconds for Notebooks
1/2/3/4. These are local timings, not portable expectations. The report combines
earlier valid outputs with a later rerun of Notebook 4. A resumed report checks
outputs, not source/dependency hashes: after substantive edits, rerun affected
notebooks. A genuine all-notebook rerun starts at 1.

`dry_run_outputs/` holds executed notebooks and the JSON report. `workshop_outputs/`
holds training artifacts, SHAP files, candidate CSVs, and images. **Exception:**
Notebooks 1–3 write four feature mapping pickle files in the project root. Keep a
separate learner copy when experimenting with new datasets so those mappings do
not silently replace another model's input vocabulary.

## Colab

The setup searches the working directory, its parent, an explicit
`POLYMER_WORKSHOP_ROOT`, and `/content/drive/MyDrive/SPE`. The Drive folder must
contain the project files directly. There is no automatic dependency installation
in the prepared notebooks. Do not claim current Colab compatibility solely from
the shared setup cell: check Python and wheel availability for the pinned stack,
install into a compatible runtime, restart if needed, and verify imports. If the
current Colab Python cannot support this stack, use local Python 3.10 or perform
an explicitly scoped migration with fresh verification.

## Concrete failure patterns

- Missing `Tg.csv` or `workshop_config`: locate the project, not the installed
  skill directory. Set `POLYMER_WORKSHOP_ROOT` before the setup cell.
- Lightning `pkg_resources` import: verify the pinned setuptools below 81. Avoid
  upgrading all dependencies as a default troubleshooting step.
- Missing `version_0/final_model.ckpt`: the prepared lab hands off the path from
  `logger.log_dir` after training. Use that checkpoint or a user-supplied trained
  one with matching alphabet/order/sequence length, not an invented download path.
- SHAP `KeyError` at sample 66: the illustrative sample must exist and must
  actually contain the highlighted fragments. If sampling or the dataset changes,
  inspect the selected molecule and choose present fragments from its fingerprint.
  Merely increasing sample count is not a general fix.
- SHAP array shape: the pinned version may return an array with a final output
  dimension instead of a list. Preserve sample and feature axes when converting.
- MFF input-width mismatch: inspect both actual selected columns and model input;
  never truncate/pad features to force a checkpoint match.
- Slow notebook: inspect cell execution timestamps first. Frequency construction
  is repeated in the first three notebooks. Caching is a possible optimization,
  but the cache must identify dataset, feature mapping, and RDKit version.
- Empty generated valid set: retain the zero-validity outcome. No candidates from
  the smoke model is a scientific outcome, not permission to invent examples.
